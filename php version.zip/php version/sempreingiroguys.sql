DROP DATABASE IF EXISTS sempreingiroguys;
CREATE DATABASE IF NOT EXISTS sempreingiroguys;
USE sempreingiroguys;

DROP TABLE IF EXISTS Users;

CREATE TABLE IF NOT EXISTS Users(
    CodUser int(11) PRIMARY KEY AUTO_INCREMENT,
    Nome varchar(100) NOT NULL,
    Cognome varchar(100) NOT NULL,
	Username CHAR(50) NOT NULL,
    Password CHAR(50) NOT NULL  
)ENGINE=InnoDB DEFAULT CHARSET=UTF8;

DROP TABLE IF EXISTS `team`;

CREATE TABLE `team` (
  `IDTeam` int(10) NOT NULL,
  `NomeTeam` varchar(50) NOT NULL,
  `Immagine` varchar(100) DEFAULT NULL,
  `Facebook` varchar(50) NOT NULL,
  `Instagram` varchar(50) NOT NULL,
  
  PRIMARY KEY (`IDTeam`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `foto`;

CREATE TABLE `foto` (
  `IDFoto` int(11) NOT NULL AUTO_INCREMENT,
  `FotoImmagine` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDFoto`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `video`;

CREATE TABLE `video` (
  `IDVideo` int(11) NOT NULL AUTO_INCREMENT,
  `VideoImmagine` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`IDVideo`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `member`;

CREATE TABLE `member` (
  `IDMember` int(11) NOT NULL AUTO_INCREMENT,
  `Nome` varchar(50) NOT NULL,
  `MemberImmagine` varchar(100) DEFAULT NULL,
    `Team` int(10),
   `Descrizione` varchar(250) NOT NULL,
   `Facebook` varchar(50) NOT NULL,
  `Instagram` varchar(50) NOT NULL,
  PRIMARY KEY (`IDMember`),
  KEY `Team` (`Team`),
  CONSTRAINT `member_ibfk_1`  FOREIGN KEY (`Team`) REFERENCES `team` (`IDTeam`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;


INSERT INTO `video` VALUES (1,'3IfX6F4xrwg'),
(2,'eVkiNIpjgnU'),
(3,'aaMAff9ECQM'),
(4,'XzNp1s8V84U'),
(5,'PBGiNrWObpk'),
(6,'dMon79PcQ3Y'),
(7,'r99M614K-Zc'),
(8,'Ue0n8ptDI3U'),
(9,'2KLOEV6VI1U'),
(10,'BmgOh-woZWU');


INSERT INTO `foto` VALUES (1,'1.jpg'),
(2,'2.jpg'),
(3,'3.jpg'),
(4,'4.jpg'),
(5,'5.jpg'),
(6,'6.jpg'),
(7,'7.jpg'),
(8,'8.jpg'),
(9,'9.jpg'),
(10,'10.jpg'),
(11,'11.jpg'),
(12,'12.jpg'),
(13,'13.jpg'),
(14,'14.jpg'),
(15,'15.jpg'),
(16,'16.jpg'),
(17,'17.jpg'),
(18,'18.jpg'),
(19,'19.jpg'),
(20,'20.jpg'),
(21,'21.jpg'),
(22,'22.jpg'),
(23,'23.jpg');



INSERT INTO `team` VALUES (1,'Deborah Mono','8.jpg','debora.mono','deb_mono?igshid=nn5y0i5dlhcz'),
(2,'Luca Apruzzese','7.jpg','jose.mou.399','luca_apru?igshid=11dt85h4qsf8c'),
(3,'Valentina Giannotti','6.jpg','valentina.giannotti','la_valetravel?igshid=rmrl4tf1ime6'),
(4,'Nicola Lettera','5.jpg','nickadventuretravels/','nickadventure_?igshid=1qx40tej1nlny'),
(5,'Laura Lorenzino','4.jpg','laura.lorenzino','lauralorenzino?igshid=su7j6dsb2vaw'),
(6,'Elena Morelli','2.jpg','elena.m.morelli','elenamorelli376?igshid=1g2dy3e0q2x7y'),
(7,'Giulia  e Samuel ','3.jpg',' ',' '),
(8,'Deborah Ferri','1.jpg','deby.thermomix','debykey75?igshid=hyhrj3ei60jh');
INSERT INTO `users` VALUES (1,'Bill','Mono','admin','admin');
INSERT INTO `member` VALUES (1,'Deborah Mono','8.jpg',1,'dhoiahxoahxoa xpohxpoa xphx pahx apxh apxh pa xhaphxpahxpah hap x','debora.mono','deb_mono?igshid=nn5y0i5dlhcz');
