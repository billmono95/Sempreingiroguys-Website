function ValidateSelection()  
{  
    var checkboxes = document.getElementsByName("choice");
     var friend = document.getElementById("friend");    
    var numberOfCheckedItems = 0;  
    for(var i = 0; i < checkboxes.length; i++)  
    {  
        if(checkboxes[i].checked)  
            numberOfCheckedItems++;
       
        if(!checkboxes[3].checked){
         
         friend.style.visibility = "hidden";

        }       
    }  
    if(numberOfCheckedItems > 1)  
    {  
        alert("Puoi fare una sola scelta!");  
        return false;  
    }

     if(checkboxes[3].checked && numberOfCheckedItems < 2 ){
         
         friend.style.visibility = "visible";

        }  
}